import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BrainShiftGameTest {

    @Test
    void displayCombo() {
        // Check that output is a combination of a letter and a number
        //String response = BrainShiftGame.displayCombo();
        //Assertions.assertEquals("A1",BrainShiftGame.displayCombo());
    }

    @Test
    void getUserInput() {
        // In a random order ask if the number is even and/or if the letter is a vowel
    }

    @Test
    void verifyLetterVowel() {
        // if the letter is a vowel, and user selects 'yes' return true, otherwise return false
    }

    @Test
    void verifyNbrEven() {
    }

    @Test
    void displayResult() {
    }
}